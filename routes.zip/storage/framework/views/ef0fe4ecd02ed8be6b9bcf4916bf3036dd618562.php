<!-- Modal -->
<div
    class="modal fade"
    id="modal-produk"
    tabindex="-1"
    role="dialog"
    aria-labelledby="modal-produk">
    <div class="modal-dialog" role="document">
       
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Pilih Produk</h4>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-hover table-bordered table-produk">
                    <thead>
                        <th width="5%">No</th>
                        <th>Kode Produk</th>
                        <th>Nama Produk</th>
                        <th>Pilih Harga</th>
                        <th><i class="fa fa-cog"></i> Aksi</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="5%"><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->kode_produk); ?></td>
                                <td><?php echo e($item->produk_name); ?></td>
                                <td>
                                    <select class="select-control" name="jenis_harga" id="jenis_harga">
                                        <option value="" selected>pilih harga</option>
                                        <option value="<?php echo e($item->harga_kiloan); ?>">Kiloan</option>
                                        <option value="<?php echo e($item->harga_botolan); ?>">Botolan</option>
                                        <option value="<?php echo e($item->harga_persak); ?>">Persak</option>
                                        <option value="<?php echo e($item->harga_customer); ?>">Customer</option>
                                        <option value=""></option>
                                    </select>
                                </td>
                                <td>
                                    <a class="btn btn-info btn-xs" href="#" onclick="pilihProduk('<?php echo e($item->id_produk); ?>','<?php echo e($item->kode_produk); ?>')"><i class="fa fa-check-circle"> pilih</i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>

<?php /**PATH D:\project\POS-PUPUK\resources\views/penjualan_detail/produk.blade.php ENDPATH**/ ?>