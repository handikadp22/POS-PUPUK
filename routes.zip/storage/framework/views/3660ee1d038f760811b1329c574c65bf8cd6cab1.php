

<?php $__env->startSection('title'); ?>
Supplier
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?> 
<li class = "active" > Supplier</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?> <div class = "row" > <div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <button onclick="addForm('<?php echo e(route('supplier.store')); ?>')" class="btn btn-success btn-sm"><i class="fa fa-plus-circle"></i> Tambah</button>
        </div>
        <div class="box-body table-responsive">
            <table class="table table-striped table-hover table-bordered">                                                  
                <thead class="text-center">
                    <th width="5%" class="text-center">No</th>
                    <th class="text-center">Nama Supplier</th>
                    <th class="text-center">Alamat</th>
                    <th class="text-center">Telepon</th>
                    <th class="text-center">
                        <i class="fa fa-cog"></i>
                        Aksi</th>
                </thead>
                <tbody class="text-center"></tbody>
            </table>
        </div>
    </div>
</div>
<?php if ($__env->exists('supplier.form')) echo $__env->make('supplier.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?> 
<script> 
let table;
$(function () {
    table = $('.table').DataTable({
        processing: true, 
        autoWidth: false,
        ajax:{
            url:'<?php echo e(route('supplier.data')); ?>', 
        },
        columns:[
            {data: 'DT_RowIndex',searchable:false, sortable:false},
            {data: 'supplier_name'},
            {data: 'alamat'},
            {data: 'telepon'},
            {data: 'aksi', searchable:false,sortable:false},
        ]
    });

    $('#modal-form').validator().on('submit',function (e){
        if (! e.preventDefault()){
            $.ajax({
                url:$('#modal-form form').attr('action'),
                type: 'post',
                data: $('#modal-form form').serialize()
            })
            .done((response)=>{
                $('#modal-form').modal('hide');
                table.ajax.reload();
            })
            .fail((errors)=>{
                alert('Tidak dapat menyimpan data');
                return;
            });
        }
    });
});

function addForm(url) {
    $('#modal-form').modal('show');
    $('#modal-form .modal-title').text('Tambah Supplier');

    $('#modal-form form')[0].reset();
    $('#modal-form form').attr('action', url);
    $('#modal-form [name=_method]').val('post');
    $('#modal_form [name=supplier_name]').focus();
}
function editForm(url) {
    $('#modal-form').modal('show');
    $('#modal-form .modal-title').text('Edit Supplier');

    $('#modal-form form')[0].reset();
    $('#modal-form form').attr('action', url);
    $('#modal-form [name=_method]').val('put');
    $('#modal_form [name=supplier_name]').focus();

    $.get(url)
    .done((response)=>{
        $('#modal-form [name=supplier_name]').val(response.supplier_name);
        $('#modal-form [name=alamat]').val(response.alamat);
        $('#modal-form [name=telepon]').val(response.telepon);
    })
    .fail((errors)=>{
        alert('Tidak dapat menampilkan data');

        return;
    })
}

function deleteData(url) {
    if(confirm('Yakin ingin menghapus data ini?')){
        $.post(url,{
        '_token' : $('[name=csrf-token]').attr('content'),
        '_method' : 'delete'
    })
    .done((response)=>{
        table.ajax.reload();
    })
    .fail((errors)=>{
        alert('Tidak dapat menghapus data');

        return;
    });
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\POS-PUPUK\resources\views/supplier/index.blade.php ENDPATH**/ ?>